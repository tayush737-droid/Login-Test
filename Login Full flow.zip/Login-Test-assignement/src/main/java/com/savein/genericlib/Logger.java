package com.savein.genericlib;

public class Logger {

	/**
	 * To print information logs on console while executing test cases.
	 * @param message Message to be printed on the console 
	 */
	 public void info(String message){
		 System.out.println("[INFO]: " + message);
	 }
}
