package com.savein.genericlib;

import java.io.File;
import java.io.IOException;
import java.time.Clock;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Sleeper;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.AssertJUnit;

import com.google.common.io.Files;
import com.savein.basedriver.Driver;

public class GenericActions extends Driver{
	
	Logger log = new Logger();
	
	public void clickOnButton(WebElement button) throws NullPointerException {
		
		try{
			log.info("clicking button: "+ button.getText());
			if(button.isDisplayed()){
				button.click();
				
			}
			log.info("Button clicked successfully");

		} catch(Exception ue){
			log.info("Exception message is: " +ue.getMessage());
			AssertJUnit.fail("Button not found to click: " + button.getText());
		}	
	}
	
	
	public void enterText(WebElement textField, String text){

		try{
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			if(textField.isDisplayed()){
				textField.clear();
				textField.sendKeys(text);
				log.info("Entered: " + text  );
				log.info("Hide soft keyboard if present");
				try{
					log.info("Soft keyboard present, hiding it");
					driver.hideKeyboard();
				} catch(Exception ue){
					log.info("Sof keyboard not present, relax");
				}
			}
		} catch(Exception ue){
			log.info("Exception message is: " +ue.getMessage());
		}	
	}
	
	
	public void waitForElementToAppear(WebElement element){
		log.info("Waiting for element to appear" + element.getText());
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	
	public void clearAppData(String packageName) throws IOException, InterruptedException, NullPointerException{
		log.info("Clearing application data via adb");
		Process process = new ProcessBuilder("bash", "-l", "-c", "adb", "shell", "pm", "clear", packageName).start();
		int exitCode = process.waitFor();
		log.info("Application data cleared: " + packageName);
	}
	
	public void checkElementPresentOnScreen(WebElement element){
		try{
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			if(element.isDisplayed()){
				log.info("Element present on screen: " +element.getText());
			}
		} catch(Exception ue){
			log.info("Exception message is: " +ue.getMessage());
			//log.info("Check the password entered is Right");
			AssertJUnit.fail("Element not found, hence failing the test");
		}
	}
		
	public void uninstallApp(String packageName) throws IOException, InterruptedException{
		log.info("Uninstalling application with packagename: " + packageName);
		ProcessBuilder pb = new ProcessBuilder("adb", "uninstall", packageName);
		Process pc = pb.start();
		pc.waitFor();
		log.info("Application with " + packageName + " package uninstalled successfully") ;
		}

	public void screenshot(String path_screenshot, String fileName) throws IOException{
		File srcFile=driver.getScreenshotAs(OutputType.FILE);
		File targetFile=new File(path_screenshot + fileName +".jpg");
		Files.copy(srcFile,targetFile);
		
	}
	
	public void recordVideoViaAdb(String videoName) throws IOException, InterruptedException{
		//Thread.sleep(15000);
		log.info("Video recording started");
		ProcessBuilder pb = new ProcessBuilder("adb", "shell", "screenrecord", "--time-limit", "10", "/sdcard/" + videoName);
		Process pc = pb.start();
		pc.waitFor();
		log.info("Video recorded and name of video is: " +videoName) ;
	}
	
	public void pullVideoFromDevice(String location, String videoName) throws IOException, InterruptedException{
		//Thread.sleep(15000);
		log.info("Getting recorded slow motion video from device to PC");
		ProcessBuilder pb = new ProcessBuilder("adb", "pull", "/sdcard/" + videoName, location);
		Process pc = pb.start();
		pc.waitFor();
		log.info("Video pulled successfully on PC at: " +location) ;
	}
	
	
}
