package com.savein.basedriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.savein.genericlib.Logger;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Driver {
	
	public static AndroidDriver driver;
	Logger log = new Logger();
	
	public void openApp() throws MalformedURLException, InterruptedException {
		 DesiredCapabilities cap = new DesiredCapabilities();
		 cap.setCapability(MobileCapabilityType.DEVICE_NAME,"OnePlus 6");
		 cap.setCapability(MobileCapabilityType.UDID,"646ff05c");
		 cap.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
		 cap.setCapability(MobileCapabilityType.PLATFORM_VERSION,"11");
		 cap.setCapability("appium:automationName", "UiAutomator2");
		 cap.setCapability("appPackage","com.saveinmerchant");
		 cap.setCapability("appActivity","com.saveinmerchant.MainActivity");
		 URL url = new URL("http://127.0.0.1:4723/wd/hub");
		 driver =  new AndroidDriver(url,cap);
		 log.info("Waiting for lottie to load!!!!!!");
		 Thread.sleep(10000);
	}
}
