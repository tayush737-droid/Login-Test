package com.savein.testcases;

import com.savein.basedriver.Driver;
import com.savein.genericlib.GenericActions;
import com.savein.genericlib.Logger;

import constants.SaveinConstant;
import io.appium.java_client.pagefactory.AndroidFindBy;
import library.SaveinLogin;

import java.io.IOException;
import java.net.MalformedURLException;

import org.junit.Rule;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestCase extends Driver {
	
		@Rule
		public static String MERCHANT_MOBILE_NUMBER = "9532808168";
		public static String SAVEIN_PACKAGE = "com.saveinmerchant";
		public GenericActions ga;
		public SaveinLogin login;
		public Logger log;
		
		
		@BeforeClass(alwaysRun = true)
		public void openApp() {
			
		}
		
		@BeforeMethod(alwaysRun = true)
		public void init() throws MalformedURLException, InterruptedException {
		super.openApp();
		ga = new GenericActions();
		login = new SaveinLogin();
		log = new Logger();
		
		}
		
		@AfterMethod(alwaysRun = true)
		public void tearDown () throws IOException, InterruptedException {
			driver.quit();
			ga.clearAppData(SAVEIN_PACKAGE);
		}
		
		@Test
		public void loginprofile() throws InterruptedException, IOException {
			ga.waitForElementToAppear(login.nextButton);
			ga.clickOnButton(login.nextButton);
			ga.clickOnButton(login.nextButton);
			ga.clickOnButton(login.getStartedButton);
			Thread.sleep(3000);
			driver.navigate().back();
			ga.waitForElementToAppear(login.merchantLoginMobileNumber);
			ga.clickOnButton(login.merchantLoginMobileNumber);
			ga.enterText(login.merchantLoginMobileNumber, MERCHANT_MOBILE_NUMBER);
			ga.clickOnButton(login.continueButton);
			ga.waitForElementToAppear(login.otp1);
			ga.enterText(login.otp1, "1");
			ga.enterText(login.otp2, "2");
			ga.enterText(login.otp3, "3");
			ga.enterText(login.otp4, "4");
			ga.clickOnButton(login.verifyButton);
			Thread.sleep(10000);
		}

}
