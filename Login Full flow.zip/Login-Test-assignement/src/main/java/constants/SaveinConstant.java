package constants;

public class SaveinConstant {
	
	//============================================================================================================================================
	/*** Profile login Constants***/
	public static final String NEXT_BUTTON = "//android.widget.TextView[@text='Next']";
	public static final String GET_STARTED_BUTTON = "//android.widget.TextView[@text='Get Started']";
	public static final String MERCHANT_LOGIN_MOBILE_NUMBER = "//android.widget.EditText[@text='Enter mobile number']";
	public static final String CONTINUE_BUTTON = "//android.widget.TextView[@text='Continue']";
	public static final String OTP_FIELD_1 = "//android.widget.EditText[@resource-id='otp_input_0']";
	public static final String OTP_FIELD_2 = "//android.widget.EditText[@resource-id='otp_input_1']";
	public static final String OTP_FIELD_3 = "//android.widget.EditText[@resource-id='otp_input_2']";
	public static final String OTP_FIELD_4 = "//android.widget.EditText[@resource-id='otp_input_3']";
	public static final String VERIFY_BUTTON = "//android.widget.TextView[@text='Verify']";
	
	//============================================================================================================================================
	/*** Profile Onboarding Constants***/
	public static final String PARTNER_MEDICAL_SELECTION_SCREEN = "//android.widget.TextView[@text='Which type of healthcare provider are you?']";
	public static final String DOCTOR_TILE = "//android.widget.TextView[@text='DOCTOR']";
	public static final String NON_MEDICAL_TILE = "//android.widget.TextView[@text='NON-MEDICAL']";
	public static final String PARTNER_MEDICAL_SELECTION_SCREEN_CONTINUE_BUTTON = "//android.widget.TextView[@text='Continue']";
	public static final String PARTNER_MEDICAL_DOMAIN_SELECTION_SCREEN = "//android.widget.TextView[@text='Which medical domain do you belong to?']";
	public static final String DOCTOR_DENTISTRY = "//android.widget.TextView[@text='Dentistry']";
	public static final String VETERINARY = "//android.widget.TextView[@text='Veterinary']";
	public static final String DERMATOLOGY = "//android.widget.TextView[@text='Dermatology']";
	public static final String OPHTHALMOLOGY = "//android.widget.TextView[@text='Ophthalmology']";
	public static final String MULTISPECIALTY_HOSPITAL = "//android.widget.TextView[@text='Multispecialty Hospital']";
	public static final String ALTERNATIVE_MEDICINE = "//android.widget.TextView[@text='Alternative Medicine']";
	public static final String HAIR_TRICHOLOGY = "//android.widget.TextView[@text='Hair & Trichology']";
	public static final String GYNAECOLOGY = "//android.widget.TextView[@text='Gynaecology']";
	public static final String IVF_CLINIC = "//android.widget.TextView[@text='IVF Clinic']";
	public static final String PARTNER_DOMAIN_SELECTION_SCREEN_GO_AHEAD = "//android.widget.TextView[@text='Go ahead']";
	public static final String PARTNER_DOMAIN_SELECTION_SCREEN_CLICK_HERE = "//android.widget.TextView[@text=' Click here ']";
	public static final String NON_MEDICAL_HEARING_AID = "//android.widget.TextView[@text='Hearing Aid']";
	public static final String NON_MEDICAL_OPTICALS = "//android.widget.TextView[@text='Opticals']";
	public static final String NON_MEDICAL_PHYSIOTHERAPY = "//android.widget.TextView[@text='Physiotherapy']";
	public static final String NON_MEDICAL_GYMNASIUM = "//android.widget.TextView[@text='Gymnasium']";
	public static final String NON_MEDICAL_BEAUTY_PERSONAL_CARE = "//android.widget.TextView[@text='Beauty & Personal care']";
	public static final String ENTER_BASIC_DETAILS_DOCTOR = "//android.widget.TextView[@text='Enter Basic Details']";
	public static final String ENTER_BASIC_DETAILS_DOCTOR_PROFILE_COMPLETE_BAR = "//android.widget.TextView[@text='50%']";
	public static final String ENTER_BASIC_DETAILS_DOCTOR_SALUTATION = "//android.widget.TextView[@text='Dr.']";
	public static final String ENTER_BASIC_DETAILS_DOCTOR_NAME_EDIT_TEXT = "//android.widget.EditText[@text='Enter your full name']";
	//public static final String ENTER_BASIC_DETAILS_DOCTOR = "//android.widget.TextView[@text='Enter Basic Details']";
	
	//============================================================================================================================================
	/*** Dashboard Constants***/
	public static final String CONTINUE_APPLICATION_BUTTON = "//android.widget.TextView[@text='Start a new application']";
	public static final String AMOUNT_RECEIVED_CARD = "//android.widget.TextView[@text='Amount received']";
	public static final String AMOUNT_IN_PROGRESS_CARD = "//android.widget.TextView[@text='Amount in progress']";
	public static final String START_NEW_APPLICATION_BUTTON = "//android.widget.TextView[@text='Start a new application']";
	public static final String INITIATE_NEW_APPLICATION_VIDEO = "//android.widget.TextView[@text='Learn how to initiate a loan application for your patients']";
	public static final String SAVEIN_APPLICATIONS_FUNNEL_CARD = "//android.widget.TextView[@text='SaveIN applications funnel']";
	public static final String VIEW_WEB_PROFILE_CARD = "//android.widget.TextView[@text='Your SaveIN profile is now LIVE']";
	public static final String VIEW_PROFILE_BUTTON = "//android.widget.TextView[@text='View profile']";
	public static final String SHARE_PROFILE_BUTTON = "//android.widget.TextView[@text='Share']";
	public static final String UPCOMING_LAUNCHES_CARD = "//android.widget.TextView[@text='Upcoming launches']";	
}
