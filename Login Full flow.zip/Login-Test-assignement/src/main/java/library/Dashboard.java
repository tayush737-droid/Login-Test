package library;

import org.openqa.selenium.support.PageFactory;

import com.savein.basedriver.Driver;
import com.savein.genericlib.GenericActions;
import com.savein.genericlib.Logger;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Dashboard {
	
protected AndroidDriver driver;
	
	GenericActions ga;
	Logger log;
	
	
	public Dashboard() {
		this.driver = Driver.driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		ga = new GenericActions();
		log = new Logger();
	}

}
