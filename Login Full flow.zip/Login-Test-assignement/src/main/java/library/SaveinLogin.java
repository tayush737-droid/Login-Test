package library;

import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.savein.basedriver.Driver;
import com.savein.genericlib.GenericActions;
import com.savein.genericlib.Logger;

import constants.SaveinConstant;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SaveinLogin extends Driver {
	
	protected AndroidDriver driver;
	
	GenericActions ga;
	Logger log;
	
	
	public SaveinLogin() {
		this.driver = Driver.driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		ga = new GenericActions();
		log = new Logger();
	}
	
	@AndroidFindBy(xpath = SaveinConstant.NEXT_BUTTON)
	public WebElement nextButton;
	
	@AndroidFindBy(xpath = SaveinConstant.GET_STARTED_BUTTON)
	public WebElement getStartedButton;
	
	@AndroidFindBy(xpath = SaveinConstant.MERCHANT_LOGIN_MOBILE_NUMBER)
	public WebElement merchantLoginMobileNumber;
	
	@AndroidFindBy(xpath = SaveinConstant.CONTINUE_BUTTON)
	public WebElement continueButton;
	
	@AndroidFindBy(xpath = SaveinConstant.OTP_FIELD_1)
	public WebElement otp1;
	
	@AndroidFindBy(xpath = SaveinConstant.OTP_FIELD_2)
	public WebElement otp2;
	
	@AndroidFindBy(xpath = SaveinConstant.OTP_FIELD_3)
	public WebElement otp3;
	
	@AndroidFindBy(xpath = SaveinConstant.OTP_FIELD_4)
	public WebElement otp4;
	
	@AndroidFindBy(xpath = SaveinConstant.VERIFY_BUTTON)
	public WebElement verifyButton;
	
	
	

}
